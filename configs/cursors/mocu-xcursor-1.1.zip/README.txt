Mocu xcursor theme 1.1
Distributed under the CC0
https://github.com/sevmeyer/mocu-xcursor
